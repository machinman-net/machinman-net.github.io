/* 
 * Copyright (C) 2008-2009 by Emmanuel Azencot under the GNU LGPL
 * license version 2.0 or 2.1.  You should have received a copy of the
 * LGPL license along with this library if you did not you can find it
 * at http://www.gnu.org/.
 */
#ifndef _EXCP_MOD_H_ /* [ */
#define _EXCP_MOD_H_

#define EXCP_MOD_RING 0x0020
#define EXCP_MOD_DWARF 0x0021

#endif /* ] _EXCP_MOD_H_ */

